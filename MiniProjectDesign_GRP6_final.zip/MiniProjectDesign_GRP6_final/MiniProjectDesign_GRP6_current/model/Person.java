package model;

/**
 * This class holds information about Persons
 *
 * @author Group 6
 * @version 1.0
 */
public class Person{
    private String name;
    private String address;
    private int postalCode;
    private String city;
    private String phoneNumber;

    /**
     *Initializes the undefined fields.
     *@param name Name of the Person
     *@param address Address of the Person
     *@param postalCode Postal Code of the Person
     *@param city City of the Person
     *@param phoneNumber Phone Number of the Person
     */

    public Person(String name, String address, int postalCode, String city, String phoneNumber){
        this.name = name;
        this.address = address;
        this.postalCode = postalCode;
        this.city = city;
        this.phoneNumber = phoneNumber;
    }
    //getters
    /**
     * This method returns the name of Person.
     * @return name of Person
     */
    public String getName(){
        return name;
    }

    /**
     * This method returns the phone number of Person.
     *@return number of Person
     */
    public String getPhoneNumber(){
        return phoneNumber;
    }
    //setters
    /**
     *This method changes the name of the Person.
     *@param newName New name to replace
     */
    public void setName(String newName){
        name = newName;
    }

    /**
     *This method changes the address of the Person.
     *@param newAddress New address to be 
     */
    public void setAddress(String newAddress){
        address = newAddress;
    }

    /**
     *This method changes the postal code of the Person.
     *@param newPostalCode New postal code to be replaced
     */
    public void setPostalCode(int newPostalCode){
        postalCode = newPostalCode;
    }

    /**
     *This method changes the city of the Person.
     *@param newCity New city to be replaced
     */
    public void setCity(String newCity){
        city = newCity;
    }

    /**
     *This method changes the phone number of the Person.
     *@param newPhoneNumber New phone number to be replaced
     */
    public void setPhoneNumber(String newPhoneNumber){
        phoneNumber = newPhoneNumber;
    }
}
