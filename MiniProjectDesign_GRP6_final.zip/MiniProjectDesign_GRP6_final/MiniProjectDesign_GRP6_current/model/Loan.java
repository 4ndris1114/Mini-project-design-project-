package model;

/**
 * This class holds information about Loans
 *
 * @author Group 6
 * @version 1.0
 */
public class Loan{
    private int id;
    private String borrowDate;
    private int period;
    private boolean state;

    /**
     *Initializes the undefined fields.
     *@param id ID of the Loan
     *@param borrowDate Borrow Date of Loan
     *@param period Period of Loan
     *@param state State of Loan
     */
    public Loan(int id, String borrowDate, int period, boolean state){
        this.id = id;
        this.borrowDate = borrowDate;
        this.period = period;
        this.state = state;
    }
    //getters
    /**
     *This method returns the ID of  Loan.
     *@return ID of Loan 
     */
    public int getID(){
        return id;
    }

    /**
     *This method returns the state of  Loan.
     *@return state of Loan.
     */
    public boolean getState(){
        return state;
    }
    //setters
    /**
     *This method changes the ID of the Loan.
     *@param newPeriod New period to be replaced
     */
    public void setPeriod(int newPeriod){
        this.period = newPeriod;
    }
}
