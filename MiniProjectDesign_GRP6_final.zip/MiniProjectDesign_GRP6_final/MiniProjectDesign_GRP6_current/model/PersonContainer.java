package model;
import java.util.ArrayList;

/**
 * This class is a container class for Persons that can hold the gathering of Persons
 *
 * @author Group 6
 * @version 1.0
 */
public class PersonContainer
{
    private static PersonContainer instance;
    private ArrayList<Person> persons;
    private ArrayList<Person> friends;

    /**
     *Initializes the undefined fields.
     */
    private PersonContainer(){
        persons = new ArrayList<>();
        friends = new ArrayList<>();
    }
    //getters
    /**
     *This method returns an instance of the PersonContainer. If the instance is empty, it initalizes it.
     *@return instance of the PersonContainer
     */
    public static PersonContainer getInstance(){
        if (instance == null){
            instance = new PersonContainer();
        }
        return instance;
    }
    //pub methods here
    /**
     *This method adds a new Person to the list of Persons
     *@param person New person to be added
     *@return whether the Person has been added successfully
     *
     */
    public boolean addPerson(Person person){
        return persons.add(person);
    }

    /**
     *This method adds a Person as a new Friend to the list of Friends
     *@param person New Person to be added
     *@return whether the Friend has been added successfully
     */
    public boolean addFriend(Person person){
        return friends.add(person);
    }

    /**
     *This method removes a selected Person from the friend list
     *@return whether the Person has been removed successfully from the friend list
     */
    public boolean removeFriend(Person person){
        return friends.remove(person);
    }

    /**
     *This method iterates through the collection of Persons to find one with a matching name
     * @param name name to be searched
     * @return person with its all attributes, empty person object if it could not find
     */
    public Person searchPersonByName(String name){
    Person returnPerson = null;
    for (Person person : persons){
        if (person.getName().equals(name)){
            returnPerson = person;
            }
        }
        return returnPerson;
    }
    
    /**
     *This method iterates through the collection of Friends to find one with a matching name
     * @param name name to be searched
     * @return person with its all attributes, empty person object if it could not find
     */
    public Person searchFriendByName(String name){
        Person returnPerson = null;
        for (Person person : friends){
            if (person.getName().equals(name)){
                returnPerson = person;
            }
        }
        return returnPerson;
    }
}