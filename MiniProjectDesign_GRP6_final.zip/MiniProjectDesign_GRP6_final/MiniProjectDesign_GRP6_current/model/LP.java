package model;
import java.util.ArrayList;

/**
 * This class holds information about LPs
 *
 * @author Group6
 * @version 1.0
 */
public class LP
{
    private String barcode;
    private String title;
    private String artist;
    private String publicationDate;
    private ArrayList<Copy> copies;

    /**
     *Initializes the undefined fields.
     *@param barcode Barcode of LP.
     *@param title Title of LP.
     *@param artist Artist of LP.
     *@param publicationDate Publication Date of LP.
     */
    public LP(String barcode, String title, String artist, String publicationDate){
        this.barcode = barcode;
        this.title = title;
        this.artist = artist;
        this.publicationDate = publicationDate;
        copies = new ArrayList<>();
    }
    //getters
    /**
     * Returns the title of LP
     * @return LP's title
     */
    public String getTitle(){
        return title;
    }
    /**
     * Returns a list of all copies belonging to an LP
     * @return List of copies
     */
    public ArrayList<Copy> getAllCopies(){
        return copies;
    }
    ///pub methods here
    /**
     * Adds a copy to the list of copies
     * @param copy New copy to be added
     * @return whether the copy was added or not
     */
    public boolean addCopy(Copy copy){
        return copies.add(copy);
    }
}
