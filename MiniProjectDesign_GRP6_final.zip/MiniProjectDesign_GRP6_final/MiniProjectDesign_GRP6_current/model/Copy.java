package model;

/**
 *This class holds information about LP's copies.
 *
 *@author Group 6
 *@version 1.0
 */
public class Copy{
    private int serialNumber;
    private String purchaseDate;
    private int purchasePrice;
    private boolean state;

    /**
     *Initializes the undefined fields
     *@param serialNumber the Serial Number of the Copy.
     *@param purchaseDate the Date the Purchase for the Copy took place.
     *@param purchasePrice the price of the Copy
     *@param state the state the Copy is in.
     */

    public Copy(int serialNumber, String purchaseDate, int purchasePrice, boolean state){
        this.serialNumber = serialNumber;
        this.purchaseDate = purchaseDate;
        this.purchasePrice = purchasePrice;
        this.state = state;
    }
    //getters
    /**
     * Returns the serial number of copy
     * @return Copy's serial number
     */
    public int getSerialNumber(){
        return serialNumber;
    }
    //setters
    /**
     * Changes the state of copy
     * @param newState New state to replace
     */
    public void setState(boolean newState){
        this.state = newState;
    }
    //pub methods here
    /**
     * Checks whether a copy is available
     * @return Copy's state
     */
    public boolean isAvailable(){ //basically gets state
        return state;
    }
}
