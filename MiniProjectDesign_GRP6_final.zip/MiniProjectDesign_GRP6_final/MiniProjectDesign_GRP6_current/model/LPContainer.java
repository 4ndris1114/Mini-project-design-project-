package model;
import java.util.ArrayList;

/**
 * This class is a container class for LPs that can hold the gathering of LPs
 *
 * @author Group 6
 * @version 1.0
 */
public class LPContainer
{
    private static LPContainer instance;
    private ArrayList<LP> lps;

    /**
     *Initializes the undefined fields.
     */
    private LPContainer(){
        lps = new ArrayList<>();
    }

    /**
     *This method returns an instance of the LPContainer. If the instance is empty, it initalizes it.
     *@return instance of the LPContainer
     */
    public static LPContainer getInstance(){
        if (instance == null){
            instance = new LPContainer();
        }
        return instance;
    }

    /**
     *This method adds a new LP to the list of LPs.
     *@param newLP New LP to be added
     *@return whether an LP has been added successfully
     */
    public boolean addLP(LP newLP){
        return lps.add(newLP);
    }

    /**
     * This method is searching through the collection of LPs to find the right copy on the basis of input serial number
     * @param serialNumber unique number distinguishing copies from each other, serial number to be searched
     * @return copy with its all attributes, empty copy object if it could not find
     */
    public Copy searchCopyBySerialNumber(int serialNumber){
        Copy returnCopy = null;
        for (LP lp : lps){
            for (Copy copy : lp.getAllCopies()){
                if (copy.getSerialNumber() == serialNumber && copy.isAvailable()){
                    returnCopy = copy;
                }
            }
        }
        return returnCopy;
    }
}
