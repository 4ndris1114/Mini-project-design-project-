package model;
import java.util.ArrayList;

/**
 * This class is a container class for Loans that can hold the gathering of Persons
 *
 * @author Group 6
 * @version 1.0
 */
public class LoanContainer
{
    private static LoanContainer instance;
    private ArrayList<Loan> loans;
    private static int idGen;

    /**
     *Initializes the undefined fields.
     */
    private LoanContainer(){
        loans = new ArrayList<>();
        idGen = 0;
    }

    /**
     *This method returns an instance of the LoanContainer. If the instance is empty, it initalizes it.
     *@return instance of the LoanContainer
     */
    public static LoanContainer getInstance(){
        if (instance == null){
            instance = new LoanContainer();
        }
        return instance;
    }

    /**
     *This method adds a new Loan to the list of Loans
     *@param loan New loan to be added
     *@return whether the Loan was added successfully
     */
    public boolean addLoan(Loan loan){
        return loans.add(loan);
    }
    public int getIDGen(){
        return idGen;
    }
    public void increaseIDGen(){
        idGen++;
    }
}
