package tui;
import controller.*;
import model.*;

/**
 * This class generates data so the programmer doesn't have to input data by themself.
 *
 * @author Group 6
 * @version 1.0
 */
public class TryMe{
    //Empty constructor
    public TryMe(){
    }
    /*
     * Method for generating datas
     * It creates 4 Person and adds them to the list which stores Persons
     * It creates 2 LPs and 3 Copies for each LP and adds them to the right list (LPss to LP list - Copies to Copies list)
     */
    public void generateData(){
        Person p1 = new Person("Dávid","Anna anchers vej 204 st.tv", 9200, "Aalborg", "12345678");
        Person p2 = new Person("András","Gronnegade 28 kl th", 9000, "Aalborg", "87654321");
        Person p3 = new Person("Katie","Gertrud rasks vej 91 st tv", 9210, "Aalborg", "12564524358");
        Person p4 = new Person("Ádin","Nibevej 12 st th", 9200, "Aalborg", "834195734");
 
        PersonContainer.getInstance().addPerson(p1);
        System.out.println(p1.getName()+" was added to the person list.");
        PersonContainer.getInstance().addPerson(p2);
        System.out.println(p2.getName()+" was added to the person list.");
        PersonContainer.getInstance().addPerson(p3);
        System.out.println(p3.getName()+" was added to the person list.");
        PersonContainer.getInstance().addPerson(p4);
        System.out.println(p4.getName()+" was added to the person list.");
        
        LP lp1 = new LP("LGBR2009", "Bad romance", "Lady Gaga", "2009");
        LPContainer.getInstance().addLP(lp1);
        System.out.println(lp1.getTitle()+" was added to the lp list.");
        Copy c1 = new Copy(1, "2010.01.01", 100, true);
        Copy c2 = new Copy(2, "2010.01.30", 90, true);
        Copy c3 = new Copy(3, "2010.03.30", 80, false);

        lp1.addCopy(c1);
        System.out.println("Serial number: "+c1.getSerialNumber()+" was added to the copy list.");
        lp1.addCopy(c2);
        System.out.println("Serial number: "+c2.getSerialNumber()+" was added to the copy list.");
        lp1.addCopy(c3);
        System.out.println("Serial number: "+c3.getSerialNumber()+" was added to the copy list.");
        
        LP lp2 = new LP("LCSYL2016", "Someone you loved", "Lewis cafasdn", "2016");
        LPContainer.getInstance().addLP(lp2);
        System.out.println(lp2.getTitle()+" was added to the lp list.");
        Copy c4 = new Copy(4, "2016.12.12", 100, true);
        Copy c5 = new Copy(5, "2017.01.01", 70, false);
        Copy c6 = new Copy(6, "2017.02.02", 50, false);
        
        lp2.addCopy(c4);
        System.out.println("Serial number: "+c4.getSerialNumber()+" was added to the copy list.");
        lp2.addCopy(c5);
        System.out.println("Serial number: "+c5.getSerialNumber()+" was added to the copy list.");
        lp2.addCopy(c6);
        System.out.println("Serial number: "+c6.getSerialNumber()+" was added to the copy list.");
    }

}
