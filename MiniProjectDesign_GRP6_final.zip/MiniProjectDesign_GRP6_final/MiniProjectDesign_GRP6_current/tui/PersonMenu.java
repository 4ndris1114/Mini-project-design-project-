package tui;
import controller.PersonController;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * This class prints PersonMenu and offers options to the user where to continue
 *
 * @author Group 6
 * @version 1.0
 */
public class PersonMenu
{
    private PersonController personController;
    private ArrayList<String> errors = new ArrayList<>();
    
    /**
     *Initializes the undefined fields
     *Creates connection to the Controller layer
     *Adds possible errors to a list
     */
    public PersonMenu(){
        personController = new PersonController();
        errors.add("Person is not on your friend list!");
        errors.add("Person is already on your friend list!");
        errors.add("Person doesn't exist");
    }
    
    /**
     *This method Starts the PersonMenu
     */
    public void start(){
        personMenu();
    }
    
    /**
     * This method makes possible for the user to add/remove a friend or to go back to the Main Menu
     * It calls PersonMenu's writePersonMenu() method, awaiting for user's choice.
     */
    private void personMenu(){
        boolean exit = false;
        while (!exit){
            int choice = writePersonMenu();
            switch (choice){
                case 1: //Adds a new friend by name. Before adding it, system checks if the new friend is on the list of persons but not on the list of friends.
                    String friendToBeAdded = askForName();
                    if (personController.searchPersonByName(friendToBeAdded) != null && !personController.isFriend(friendToBeAdded)){
                        personController.addFriend(personController.searchPersonByName(friendToBeAdded));
                        System.out.println(friendToBeAdded+" was added to your friend list!\n");
                    }
                    else{
                        System.out.println("\nYou couldn't add "+friendToBeAdded+" to your friendlist.");
                        System.out.println("Possible errors:");
                        System.out.println(1);
                        System.out.println(errors.get(2));
                    }
                    break;
                case 2:
                    //Removes a friend by name. Before removing it, system checks if the new friend is not on the list of persons but on the list of friends.
                    String friendToBeRemoved = askForName();
                    if(personController.searchPersonByName(friendToBeRemoved) != null && personController.isFriend(friendToBeRemoved)){
                        personController.removeFriend(personController.searchPersonByName(friendToBeRemoved));
                        System.out.println(friendToBeRemoved+" was removed from your friend list!\n");
                    }
                    else{
                        System.out.println("\nYou couldn't remove "+friendToBeRemoved+" from your friendlist.");
                        System.out.println("Possible errors:");
                        System.out.println(errors.get(0));
                        System.out.println(errors.get(2));
                    }
                    break;
                case 9:
                    exit = true;
                    clearScreen();
                    break;
                default: System.out.println("An error occured, your choice was: "+choice);
                    break;
            }
        }
    }
    
    /**
     *This method prints out the PersonMenu and waits for the user's correct input
     *@return the user's choice.
     */
    private int writePersonMenu(){
        Scanner key = new Scanner(System.in);
        System.out.println("\n\t****Person Menu****");
        System.out.println("[1] Add friend");
        System.out.println("[2] Remove friend");
        System.out.println("[9] Back to Main Menu");
        System.out.print("\nEnter your choice: ");
        while (!key.hasNextInt()){
            System.out.println("\nYour choice must be a number, come again: ");
            key.nextLine();
        }
        int yourChoice = key.nextInt();
        return yourChoice;
    }
    /**
     *This method waits for the user to input a name, which is used later for searching
     */
    private String askForName(){
        System.out.print("Enter the name of the peson: ");
        Scanner name = new Scanner(System.in);
        return name.nextLine();
    }
    
    /**
     * This method clears the screen.
     */
    private void clearScreen(){
        System.out.print("\f");
    }
}