package tui;
import java.util.Scanner;
import tui.TryMe;

/**
 * The first interface the user is opposed to. It offers choices to continue to further menus.
 *
 * @author Group 6
 * @version 1.0
 */
public class MainMenu
{
    private LoanMenu loanMenu;
    private LPMenu lpMenu;
    private PersonMenu personMenu;
    private TryMe tryMe;

    /**
     *Initializes the undefined fields
     *Creates connection between menus
     */
    public MainMenu()
    {
        loanMenu = new LoanMenu();
        lpMenu = new LPMenu();
        personMenu = new PersonMenu();
        tryMe = new TryMe();
    }

    /**
     *This method Starts the program.
     */
    public void start(){
        mainMenu();
    }

    /**
     * This method makes possible to step between menus by calling other menu classes start method.
     * It calls MainMenu's writeMainMenu() method, awaiting for user's choice.
     */
    private void mainMenu(){
        boolean exit = false;
        while (!exit){
            int choice = writeMainMenu();
            switch (choice){
                case 1: //Calls PersonMenu's start method
                    personMenu.start();
                    break;
                case 2: //Calls LoanMenu's start method
                    loanMenu.start();
                    break;
                case 3: //Calls LPMenu's start method
                    lpMenu.start();
                    break;
                case 9: //Calls TryMe class's generate testdata's method
                    tryMe.generateData();
                    
                    break;
                case 0: //Quits the program
                    exit = true;
                    System.out.println("Tak fordi du bruger denne applikation. Hasta la vista!");
                    break;
                default: //Every other case it prints error message then refreshes the page in 3 seconds
                    System.out.println("An error occured, your choice was: "+choice);
                    try{
                        System.out.println("Refresh in 3");
                        Thread.sleep(1000);
                        System.out.println("Refresh in 2");
                        Thread.sleep(1000);
                        System.out.println("Refresh in 1");
                        Thread.sleep(1000);
                        clearScreen();  
                    }
                    catch (InterruptedException ie){
                        ie.printStackTrace();
                    }
                    break;
            }
        }
    }

    /**
     *This method prints out the MainMenu and waits for the user's correct input
     *@return the user's choice.
     */
    private int writeMainMenu(){
        Scanner key = new Scanner(System.in);
        System.out.println("\n\t****Main Menu****"); 
        System.out.println(" [1] Person Menu");
        System.out.println(" [2] Loan Menu");
        System.out.println(" [3] LP Menu");
        System.out.println(" [9] Generate Testdata");
        System.out.println(" [0] Quit");
        System.out.print("\nEnter your choice: ");

        while (!key.hasNextInt()){
            System.out.print("\nYour choice must be a number, come again: ");
            key.nextLine();
        }
        int yourChoice = key.nextInt();
        return yourChoice;
    }
    
    /**
     * This method clears the screen.
     */
    private void clearScreen(){
        System.out.print("\f");
    }
}
