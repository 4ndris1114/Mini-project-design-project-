package tui;
import java.util.Scanner;
import controller.LPController;

/**
 * This class prints LPMenu and offers options to the user where to continue
 *
 * @author Group 6
 * @version 1.0
 */
public class LPMenu
{
    private LPController lpController;
    
    /**
     *Initializes the undefined fields
     *Creates connection to the Controller layer
     */
    public LPMenu(){
        lpController = new LPController();
    }
    
    /**
     *This method Starts the LoanMenu
     */
    public void start(){
        lpMenu();
    }
    
    /**
     * This method makes possible for the user to: add new LP, remove existing LP, update info about LP, or to go back to the Main Menu
     * It calls LPMenu's writeLPMenu() method, awaiting for user's choice.
     */
    private void lpMenu(){
        boolean exit = false;
        while (!exit){
            int choice = writeLPMenu();
            switch (choice){
                case 1:
                    //todo
                    break;
                case 2: 
                    //todo
                    break;
                case 3:
                    //todo
                    break;
                case 9:
                    clearScreen();
                    exit = true;
                default:
                    System.out.println("An error occured, your choice was: "+choice);
                    break;
                }
        }
    }
    
    /**
     *This method prints out the LPMenu and waits for the user's correct input
     *@return the user's choice.
     */
    private int writeLPMenu(){
        Scanner key = new Scanner(System.in);
        System.out.println("\n\t****LP Menu****");
        System.out.println("[1] Add LP");
        System.out.println("[2] Remove LP");
        System.out.println("[3] Update information about LP");
        System.out.println("[9] Back to Main Menu");
        System.out.print("\nEnter your choice: ");
        while (!key.hasNextInt()){
            System.out.println("\nYour choice must be a number, come again: ");
            key.nextLine();
        }
        int yourChoice = key.nextInt();
        return yourChoice;
    }
    
    /**
     * This method clears the screen.
     */
    private void clearScreen(){
        System.out.print("\f");
    }
}
