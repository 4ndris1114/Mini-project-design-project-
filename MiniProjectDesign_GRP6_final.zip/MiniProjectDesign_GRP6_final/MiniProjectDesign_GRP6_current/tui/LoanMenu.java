package tui;
import java.util.Scanner;
import controller.LoanController;

/**
 * This class prints LoanMenu and offers options to the user where to continue
 *
 * @author Group 6
 * @version 1.0
 */
public class LoanMenu
{
    private LoanController loanController;

    /**
     *Initializes the undefined fields
     *Creates connection to the Controller layer
     */
    public LoanMenu(){
        loanController = new LoanController();
    }

    /**
     *This method Starts the LoanMenu
     */
    public void start(){
        loanMenu();
    }
    
    /**
     * This method makes possible for the user to create a new Loan or to go back to the Main Menu
     * It calls LoanMenu's writeLoanMenu() method, awaiting for user's choice.
     */
    private void loanMenu(){
        boolean exit = false;
        while (!exit)
        {
            int choice = writeLoanMenu();
            switch (choice){
                case 1: //Asks the borrower's name. If the borrower is on the list of persons
                    System.out.println("Enter borrower's name: ");
                    String borrowerName = askForName();
                    while (loanController.checkPersonExistance(borrowerName) == false || loanController.checkFriendShip(borrowerName) == false){
                        System.out.print("Person doesn't exist or not your friend...try again: ");
                        borrowerName = askForName();
                    }
                    System.out.print("Enter borrow date: ");
                    Scanner borrowDateIn = new Scanner(System.in);
                    String borrowDate = borrowDateIn.nextLine();
                    System.out.print("Enter period of loan: ");
                    Scanner periodIn = new Scanner(System.in);
                    int period = periodIn.nextInt();
                    int serialNumber = askForSerialNumber();
                    if (loanController.searchCopyBySerialNumber(serialNumber)){
                        loanController.createLoan(borrowDate, period, serialNumber);
                        System.out.println("Loan created");
                        System.out.println("Borrower: "+borrowerName+"\nDate of borrowal: "+borrowDate+"\nReturning in: "+period+" days.");
                    }
                    else{
                    System.out.println("Loan couldn't not be created, copy not available!");
                    }
                    break;
                case 9:
                    clearScreen();
                    exit = true;
                    break;
                default:
                    System.out.println("An error occured, your choice was: "+choice);
                break;
            }
        }
    }
    
    /**
     *This method prints out the LoanMenu and waits for the user's correct input
     *@return the user's choice.
     */
    private int writeLoanMenu(){
        Scanner key = new Scanner(System.in);
        System.out.println("\n\t****Loan Menu****");
        System.out.println("[1] Create Loan");
        System.out.println("[9] Back to Main Menu");
        System.out.print("Enter your choice: ");
        System.out.println("");
        while (!key.hasNextInt()){
            System.out.print("\nYour choice must be a number, come again: ");
            key.nextLine();
        }
        int yourChoice = key.nextInt();
        return yourChoice;
    }
    /**
     *This method waits for the user to input a name, which is used later for searching
     */
    private String askForName(){
        Scanner name = new Scanner(System.in);
        return name.nextLine();
    }
    /**
     *This method waits for the user to input a serial number, which is used later for searching
     */
    private int askForSerialNumber(){
        System.out.print("Enter serial number of copy to be loaned: ");
        Scanner serialNumber = new Scanner(System.in);
        return serialNumber.nextInt();
    }
    
    /**
     * This method clears the screen.
     */
    private void clearScreen(){
        System.out.print("\f");
    }
}
