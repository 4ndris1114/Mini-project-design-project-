package controller;
import model.PersonContainer;
import model.Person;

/**
 * This class controls the data flow into model layer's PersonContainer
 *
 * @author Group 6
 * @version 1.0
 */
public class PersonController
{
    //empty constructor
    public PersonController()
    {
    }
    /**
     *This method calls the PersonContainer's method to add a new Person to the friend list
     *@param newFriend New Friend to be added.
     *@return the Person (the new friend), if it could not add the Person to the list of friends it returns an empty Person object
     */
    public Person addFriend(Person newFriend){
        if (PersonContainer.getInstance().addFriend(newFriend) == false){
            newFriend = null;
        }
        return newFriend;
    }

    /**
     *This method removes a selected Friend.
     *@param friend Friend to be deleted
     *@return returns that a friend has been removed.
     */
    /**
     *This method calls the PersonContainer's method to remove the Person given from this firend list
     *@param friend Person to be removed from the friend list
     *@return the Person who has been removed from the friend list, if it could not remove the Person from the list of friends it returns an empty Person object
     */
    public Person removeFriend(Person friend){
        if (PersonContainer.getInstance().removeFriend(friend) == false){
            friend = null;
        }
        return friend;
    }

    /**
     *This method calls the PersonContainer's method to search through the list of Persons to find a person with a given name
     *@param name Name to be searched by
     *@return the Person with its all attributes, empty Person object if it could not find.
     */
    public Person searchPersonByName(String name){
        return PersonContainer.getInstance().searchPersonByName(name);
    }

    /**
     *This method calls the PersonContainer's method to search through the list of friends, whether a Person with a given name is on the list
     *@param name Name to be searched and checked by
     *@return whether the searched person is in the collection of friends
     */
    public boolean isFriend(String name){
        return PersonContainer.getInstance().searchFriendByName(name) != null;
    }
}