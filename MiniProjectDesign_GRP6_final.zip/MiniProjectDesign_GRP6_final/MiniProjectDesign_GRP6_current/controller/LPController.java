package controller;
import model.LPContainer;
import model.LP;
import model.Copy;

/**
 * This class controls the data flow into model layer's LPContainer
 *
 * @author Group 6
 * @version 1.0
 */
public class LPController
{
    //empty constructor
    public LPController()
    {
    }

    /**
     *This method calls the LPContainer's method to add a new LP.
     *@param barcode the identification/barcode of the method adds to the list
     *@param title the Title of the LP the method adds to the list
     *@param artist the Artist of the LP the method adds to the list
     *@param publicationDate the Date the LP when it has been Published.
     *@return the new LP, if it could not add the the list of lps it returns an empty lp object
     */
    public LP addLP(String barcode, String title, String artist, String publicationDate){
        LP newLP = new LP(barcode, title, artist, publicationDate);
        if (LPContainer.getInstance().addLP(newLP) == false){
            newLP = null;
        }
        return newLP;
    }

    /**
     *This method calls the LPContainer's method to search through the collection of lp's copies to find a copy with a given serial number
     *@param serialNumber Serial Number to be searched by.
     *@return the copy with its all attributes, empty copy object if it could not find.
     */
    public Copy searchCopyBySerialNumber(int serialNumber){
        return LPContainer.getInstance().searchCopyBySerialNumber(serialNumber);
    }
}
