package controller;
import model.Loan;
import model.LoanContainer;

/**
 * This class controls the data flow into model layer's LoanContainer
 *
 * @author Group 6
 * @version 1.0
 */
public class LoanController{
    PersonController personController;
    LPController lpController;

    /**
     * Initializes the undefined fields
     * By initializing these fields, it creates connection between controllers
     */
    public LoanController(){
        personController = new PersonController();
        lpController = new LPController();
    }

    /**
     *This method creates a New Loan and calls LoanContainer to increase the unique identification and also to add the new loan to the list of loans
     *@param borrowDate the date when the borrow was made
     *@param period lifetime of loan
     *@return The new loan which has been created
     */
    public Loan createLoan(String borrowDate, int period, int serialNumber){
        Loan newLoan = new Loan(LoanContainer.getInstance().getIDGen(),borrowDate, period, true);
        LoanContainer.getInstance().increaseIDGen();
        LoanContainer.getInstance().addLoan(newLoan);
        lpController.searchCopyBySerialNumber(serialNumber).setState(false);
        //set copy status to false
        return newLoan;
    }

    /**
     *This method calls the PersonContainer's method to check if a Person with a given name exists
     *@param name the name to be checked/searched by
     *@return whether the Person the method is searching for is on the list of persons
     */
    public boolean checkPersonExistance(String name){
        boolean exists = false;
        if (personController.searchPersonByName(name) != null){
            exists = true;
        }
        return exists;
    }

    /**
     *This method calls PersonController's method the check whether a Person with a given name is in friendship with the lender
     *@param name the name to be checked/searched by
     *@return whether the Person is on the Friend list.
     */

    public boolean checkFriendShip(String name){
        boolean friendship = false;
        if (personController.isFriend(name) == true){
            friendship = true;
        }
        return friendship;
    }

    /**
     *This method calls LPController's method to searches after a Copy by its Serial Number in the list of lp's copies
     *@param serialNumber Serial Number to be searched by.
     *@return whether the Copy which the method was searching for is on the list of lp's copies
     */
    public boolean searchCopyBySerialNumber(int serialNumber){
        return lpController.searchCopyBySerialNumber(serialNumber) != null && lpController.searchCopyBySerialNumber(serialNumber).isAvailable() == true;
    }
}
